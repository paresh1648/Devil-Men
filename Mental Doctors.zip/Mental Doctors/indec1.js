var a=document.getElementById("in").value;
var b=document.getElementById("thoughtarea").value;
function abc(){
	if(typeof(Storage)!=="undefined"){
		localStorage.setItem("Topic",a);
	     document.write(localStorage.getItem("Topic"));
	}
	else{
		document.write("Sorry your web browser doesnt support web storage");
	}
}